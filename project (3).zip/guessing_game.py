import random
    
print ("Welcome to the number Guessing Game! Have Fun and Goodluck!!")

num = random.randint(1, 11)
player_guess = 0
tries = 0

 
while player_guess != num:
  try:
    player_guess = int(input("Please pick a number between 1 and 10:  "))
  except ValueError:
        print('Invalid guess. Please enter a number.')
        continue
  tries += 1
    
  if player_guess < num:
    print("It is higher")
    
  elif player_guess > num:
    print("It is lower")
    
  else:
    player_guess == num
    print("Got it!! You guessed the number in  "    + str (tries) +   "  tries!")
    print("Closing game, see you next time!")
        
